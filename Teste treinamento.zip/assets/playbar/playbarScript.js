cp.playbarAssetArr = 
[
	'AudioOff',
	'AudioOn',
	'BackGround',
	'Backward',
	'Color',
	'ColorSmall',
	'CC',
	'Exit',
	'FastForward',
	'FastForward1',
	'FastForward2',
	'Forward',
	'Glow',
	'GlowSmall',
	'Height',
	'InnerStroke',
	'InnerStrokeSmall',
	'Play',
	'Pause',
	'Progress',
	'Rewind',
	'Shade',
	'ShadeSmall',
	'Stroke',
	'StrokeSmall',
	'Thumb',
	'ThumbBase',
	'TOC'
];
cp.playbarTooltips = 
{
	AudioOff : "Áudio desligado ",
	AudioOn : "Áudio ligado ",
	Backward : "Voltar ",
	CC : "Legenda codificada ",
	Exit : "Sair ",
	FastForward : "Velocidade 2x de avançar ",
	FastForward1 : "Velocidade 4x de avançar ",
	FastForward2 : "Velocidade normal ",
	Forward : "Avançar ",
	Play : "Reproduzir ",
	Pause : "Pausar ",
	Rewind : "Retroceder " ,
	TOC : "Índice analítico ",
	Info : "Informações ",
	Print : "Imprimir "
};
cp.handleSpecialForPlaybar = function(playbarConstruct)
{
}